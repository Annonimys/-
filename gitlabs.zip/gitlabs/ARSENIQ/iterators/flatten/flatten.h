#pragma once

class FlattenedVector {
    // Your code here
};
