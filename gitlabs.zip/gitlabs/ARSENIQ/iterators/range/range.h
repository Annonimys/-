#pragma once

class Range {
    // Your code here
};
