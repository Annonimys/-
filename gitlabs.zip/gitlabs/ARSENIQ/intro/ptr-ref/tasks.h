#pragma once

namespace NPointers {
    /* To implement:
    Increment
    Multiply
    ScalarProduct
    SizeOfMaximumSquareOfCrosses
    MultiplyToLongLong
    */
}

namespace NReferences {
    /* To implement:
    MultiplyInplace
    CompareArraysByAverage
    */
}
