class Timer {
public:
    bool Expired() const;
};

class TimeMeasurer {
};
