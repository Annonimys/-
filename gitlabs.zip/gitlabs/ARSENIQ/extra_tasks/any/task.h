#pragma once

class Any {
};
