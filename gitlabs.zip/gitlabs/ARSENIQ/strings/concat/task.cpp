#include "task.h"

char* concat(const char* lhs, const char* rhs) {
}
