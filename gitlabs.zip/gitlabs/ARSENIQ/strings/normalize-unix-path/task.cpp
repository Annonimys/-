#include <string>
#include <iterator>

using namespace std;

string normalize(string_view path) {
}
