bool isalpha(unsigned char c) {
}

unsigned char tolower(unsigned char c) {
}
