#include "task.h"

bool is_palindrome(const std::string& s) {
}
