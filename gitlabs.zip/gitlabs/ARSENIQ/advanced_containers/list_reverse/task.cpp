#include "task.h"

void ReverseList(std::list<int>& l) {
}
